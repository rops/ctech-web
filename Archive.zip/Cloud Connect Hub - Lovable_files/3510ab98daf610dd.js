;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="11f87d8f-7d0e-f19d-de24-8123cb7ef94e")}catch(e){}}();
(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,314658,e=>{"use strict";var t=e.i(418883),a=e.i(961078),n=e.i(971195),s=e.i(48105),i=e.i(360112),r=e.i(606755),l=e.i(765641),o=e.i(207057),c=e.i(669285);let d={successEvent:"dev_environment_enabled",failedEvent:"dev_environment_enable_failed"};function u({onSuccess:e,onError:p,platform:m="desktop",analytics:f=d}={}){let{client:h}=(0,c.useCloudApiClientWrapper)(),g=(0,r.useProjectStore)(e=>e.project),x=(0,r.useProjectStore)(e=>e.setIsEnablingDevEnvironment),y=(0,a.useQueryClient)(),[b,j]=(0,s.useState)({phase:"idle"}),v=(0,t.useMutation)({mutationFn:async()=>{if(!h)throw Error("API client not available");return h.post("enable-environments")},onSuccess:()=>{y.invalidateQueries({queryKey:["cloud",g?.id]}),y.invalidateQueries({queryKey:o.projectKeys.integration(g?.id??"","supabase")}),y.invalidateQueries({queryKey:o.projectKeys.detail(g?.id??"")})}}),E=(0,s.useCallback)(async()=>{if(g?.id){j({phase:"enabling"}),x(!0);try{await v.mutateAsync(),n.default.capture(f.successEvent,{project_id:g.id,..."mobile"===m&&{platform:"mobile"}}),j({phase:"success"}),e?.()}catch(t){let e=t instanceof Error?t:Error("Failed to enable dev environment");l.logging.error("Failed to enable dev environment",{error:e,projectId:g.id}),i.toast.error("Error",{description:"Failed to set up test database. Please try again."}),n.default.capture(f.failedEvent,{project_id:g.id,error_message:e.message,..."mobile"===m&&{platform:"mobile"}}),j({phase:"error",error:e}),p?.(e)}finally{x(!1)}}},[g?.id,v,e,p,m,f,x]),N=(0,s.useCallback)(()=>{j({phase:"idle"})},[]);return{enableDevEnvironment:E,status:b,isEnabling:"enabling"===b.phase,isSuccess:"success"===b.phase,isError:"error"===b.phase,error:"error"===b.phase?b.error:null,resetStatus:N}}function p({onSuccess:e}={}){let{client:i}=(0,c.useCloudApiClientWrapper)(),l=(0,r.useProjectStore)(e=>e.project),d=(0,r.useProjectStore)(e=>e.setSelectedCloudInstance),u=(0,a.useQueryClient)(),[m,f]=(0,s.useState)({phase:"idle"}),h=(0,t.useMutation)({mutationFn:async()=>{if(!i)throw Error("API client not available");return i.post("disable-dev-environment")},onSuccess:()=>{d("prod"),u.invalidateQueries({queryKey:["cloud",l?.id]}),u.invalidateQueries({queryKey:o.projectKeys.integration(l?.id??"","supabase")}),u.invalidateQueries({queryKey:o.projectKeys.detail(l?.id??"")})}}),g=(0,s.useCallback)(async()=>{if(l?.id){f({phase:"disabling"});try{await h.mutateAsync(),n.default.capture("dev_environment_disabled",{project_id:l.id}),f({phase:"success"}),e?.()}catch(t){let e=t instanceof Error?t:Error("Failed to disable dev environment");n.default.capture("dev_environment_disable_failed",{project_id:l.id,error_message:e.message}),f({phase:"error",error:e})}}},[l?.id,h,e]),x=(0,s.useCallback)(()=>{f({phase:"idle"})},[]);return{disableDevEnvironment:g,status:m,isDisabling:"disabling"===m.phase,isSuccess:"success"===m.phase,isError:"error"===m.phase,error:"error"===m.phase?m.error:null,resetStatus:x}}e.s(["useDisableDevEnvironment",()=>p,"useEnableDevEnvironment",()=>u])},642655,e=>{"use strict";var t=e.i(855205),a=e.i(721636),n=e.i(180580),s=e.i(448020);e.s(["BetaBadge",0,({className:e,tooltipContent:i="This experimental feature is still under development",showTooltip:r=!0})=>{let l=(0,t.jsx)(a.Badge,{"aria-label":"Beta feature",size:"sm",className:(0,s.cn)("text-xs",e),children:"Beta"});return r?(0,t.jsxs)(n.Tooltip,{children:[(0,t.jsx)(n.TooltipTrigger,{asChild:!0,children:l}),(0,t.jsx)(n.TooltipContent,{children:(0,t.jsx)("p",{children:i})})]}):l}])},6182,e=>{"use strict";var t=e.i(606755),a=e.i(292906),n=e.i(838248);function s(){let e=(0,t.useProjectStore)(e=>e.project),s=e?.supabase_project_config,i=(0,a.useSupabaseOrganizations)({workspaceId:e?.workspace_id??""}),{selectedInstance:r}=(0,t.useSelectedCloudInstance)(),{supabaseIntegrationData:l}=(0,n.useSupabaseIntegrationData)(e?.id),o=!!e?.supabase_project_config?.supabase_project_id,c=l?.[r]?.supabase_project_id??null;c||(c=e?.supabase_project_config?.supabase_project_id??null);let d=function(e,t){if(e.isLoading||!t||!e.supabaseOrganizations)return!1;if(e.noOrganizations)return!0;let a=e.supabaseOrganizations.find(e=>e.id===t);return!a||"connected"!==a.status}(i,o?s?.supabase_organization_id??null:l?.[r]?.supabase_organization_id??null),u=i.supabaseOrganizations?.flatMap(e=>e.projects||[]);return!d&&u&&c&&u.find(e=>e.id===c)||null}e.s(["useConnectedSupabaseProject",()=>s],6182)},844490,e=>{"use strict";var t=e.i(48105),a=e.i(606755),n=e.i(669285),s=e.i(446129);e.s(["useCloudInstanceExhaustion",0,()=>{let e=(0,a.useProjectStore)(e=>e.project),i=(0,s.useProjectHasLovableCloudEnabled)(e),{data:r,isLoading:l,error:o}=(0,n.useGetExhaustion)({enabled:i}),{mutate:c,isPending:d,data:u}=(0,n.useDismissExhaustion)(),p=(0,t.useMemo)(()=>!!i&&!l&&!o&&!!r&&r.is_exhausted,[r,l,o,i]);return{shouldUpgradeCloudInstance:p,exhaustionRecords:(0,t.useMemo)(()=>r?.exhaustion_records?r.exhaustion_records:[],[r]),dismissExhaustion:c,isDismissing:d,wasDismissed:(0,t.useMemo)(()=>{if(u?.success)return!0;if(!r?.dismissed_at)return!1;let e=new Date(r.dismissed_at);return!r.exhaustion_records?.some(t=>new Date(t.alert_time)>e)},[r,u])}}])},682213,649350,883519,471402,753885,e=>{"use strict";var t=e.i(855205),a=e.i(968689),n=e.i(313433),s=e.i(180580),i=e.i(669285);let r={"us-east-1":{label:"US East (N. Virginia)"},"us-east-2":{label:"US East (Ohio)"},"us-west-1":{label:"US West (N. California)"},"us-west-2":{label:"US West (Oregon)"},"af-south-1":{label:"Africa (Cape Town)"},"ap-east-1":{label:"Asia Pacific (Hong Kong)"},"ap-east-2":{label:"Asia Pacific (Taipei)"},"ap-south-1":{label:"Asia Pacific (Mumbai)"},"ap-south-2":{label:"Asia Pacific (Hyderabad)"},"ap-southeast-1":{label:"Asia Pacific (Singapore)"},"ap-southeast-2":{label:"Asia Pacific (Sydney)"},"ap-southeast-3":{label:"Asia Pacific (Jakarta)"},"ap-southeast-4":{label:"Asia Pacific (Melbourne)"},"ap-southeast-5":{label:"Asia Pacific (Malaysia)"},"ap-southeast-6":{label:"Asia Pacific (New Zealand)"},"ap-southeast-7":{label:"Asia Pacific (Thailand)"},"ap-northeast-1":{label:"Asia Pacific (Tokyo)"},"ap-northeast-2":{label:"Asia Pacific (Seoul)"},"ap-northeast-3":{label:"Asia Pacific (Osaka)"},"ca-central-1":{label:"Canada (Central)"},"ca-west-1":{label:"Canada West (Calgary)"},"eu-central-1":{label:"Europe (Frankfurt)"},"eu-central-2":{label:"Europe (Zurich)"},"eu-west-1":{label:"Europe (Ireland)"},"eu-west-2":{label:"Europe (London)"},"eu-west-3":{label:"Europe (Paris)"},"eu-south-1":{label:"Europe (Milan)"},"eu-south-2":{label:"Europe (Spain)"},"eu-north-1":{label:"Europe (Stockholm)"},"il-central-1":{label:"Israel (Tel Aviv)"},"mx-central-1":{label:"Mexico (Central)"},"me-south-1":{label:"Middle East (Bahrain)"},"me-central-1":{label:"Middle East (UAE)"},"sa-east-1":{label:"South America (São Paulo)"}};function l(){let{data:e,isLoading:l}=(0,i.useGetInfo)();if(l||!e)return(0,t.jsxs)("div",{className:"flex flex-col gap-4",children:[(0,t.jsx)("p",{className:"font-medium",children:"General"}),(0,t.jsxs)("div",{className:"grid grid-cols-2 gap-5",children:[(0,t.jsxs)("div",{className:"flex flex-col gap-1",children:[(0,t.jsx)(n.Skeleton,{className:"h-4 w-24"}),(0,t.jsx)(n.Skeleton,{className:"h-5 w-36"})]}),(0,t.jsxs)("div",{className:"flex flex-col gap-1",children:[(0,t.jsx)(n.Skeleton,{className:"h-4 w-28"}),(0,t.jsx)(n.Skeleton,{className:"h-5 w-20"})]})]})]});let{region:o,postgres_version:c}=e,d=r[o]??{label:o};return(0,t.jsxs)("div",{className:"flex flex-col gap-4",children:[(0,t.jsx)("p",{className:"font-medium",children:"General"}),(0,t.jsxs)("div",{className:"grid grid-cols-2 gap-5",children:[(0,t.jsxs)("div",{className:"flex flex-col text-sm",children:[(0,t.jsx)("p",{className:"font-medium text-muted-foreground",children:"Project location"}),(0,t.jsxs)(s.Tooltip,{children:[(0,t.jsx)(s.TooltipTrigger,{asChild:!0,children:(0,t.jsx)("p",{className:"w-fit cursor-default text-base",children:d.label})}),(0,t.jsx)(s.TooltipContent,{children:o})]})]}),(0,t.jsxs)("div",{className:"flex flex-col text-sm",children:[(0,t.jsx)("p",{className:"font-medium text-muted-foreground",children:"Database version"}),(0,t.jsxs)("div",{className:"flex items-center gap-1",children:[(0,t.jsx)(a.DatabaseIcon,{size:"small"}),(0,t.jsx)("p",{className:"text-base",children:c})]})]})]})]})}e.s(["GeneralInfoCard",()=>l],682213);var o=e.i(234025),c=e.i(721636),d=e.i(448020);e.s(["CurrentInstance",0,({statusInfo:e,isLoading:a,isTransitioning:n,currentInstanceDetail:s})=>(0,t.jsx)("div",{className:"flex min-h-11 items-center gap-2 rounded-lg border bg-muted px-3 py-2 text-sm shadow-none",children:a?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(o.Spinner,{size:"small",className:"text-muted-foreground"}),(0,t.jsx)("span",{children:"Loading instance..."})]}):e?(0,t.jsxs)(t.Fragment,{children:[n?(0,t.jsx)(o.Spinner,{size:"small",className:"w-4 text-foreground"}):(0,t.jsx)("div",{className:"flex h-4 w-4 items-center justify-center",children:(0,t.jsx)("span",{className:(0,d.cn)("h-1.5 w-1.5 rounded-full","info"===e.type&&"bg-success-primary","warning"===e.type&&"bg-warning-primary","error"===e.type&&"bg-destructive-primary")})}),(0,t.jsx)("span",{children:e.description})]}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(c.Badge,{className:"font-medium",variant:s?.label?"accent":"outline",children:s?.label||"—"}),(0,t.jsx)("div",{className:"flex flex-col",children:(0,t.jsx)("span",{children:s?.description||"Select an instance to view details."})})]})})],649350);var u=e.i(959287);function p({open:e,onOpenChange:a,onConfirm:n,isLoading:s}){return(0,t.jsx)(u.TypeConfirmDialog,{open:e,onOpenChange:a,title:"Delete test database",description:(0,t.jsxs)("div",{className:"flex flex-col gap-2",children:[(0,t.jsx)("p",{children:"This will permanently delete all data in your test database. Your live database and published app won't be affected."}),(0,t.jsxs)("p",{children:["You can set up a new test database later, but this data can't be recovered. Type"," ",(0,t.jsx)("span",{className:"font-medium",children:"DELETE"})," to confirm."]})]}),confirmText:"Delete test database",confirmVariant:"destructive",confirmationText:"DELETE",confirmationPlaceholder:"DELETE",isLoading:s,onConfirm:n})}e.s(["DisableDevEnvironmentDialog",()=>p],883519);var m=e.i(247132);function f({open:e,onOpenChange:a,onConfirm:n,isLoading:s}){return(0,t.jsx)(u.TypeConfirmDialog,{open:e,onOpenChange:a,icon:m.WarningTriangleIcon,title:"Disconnect Cloud",description:(0,t.jsxs)("div",{className:"space-y-3",children:[(0,t.jsx)("p",{children:(0,t.jsx)("strong",{children:"This action is irreversible."})}),(0,t.jsxs)("ul",{className:"list-disc space-y-1 pl-4",children:[(0,t.jsx)("li",{children:"Your database, file storage, and all Cloud data will be permanently deleted and cannot be recovered."}),(0,t.jsx)("li",{children:"Some parts of your app that rely on Cloud features may stop working."})]}),(0,t.jsxs)("p",{children:["Type ",(0,t.jsx)("strong",{children:"CONFIRM"})," below to proceed."]})]}),confirmText:"Disconnect Cloud",confirmVariant:"destructive",confirmationText:"CONFIRM",confirmationPlaceholder:"Type CONFIRM",isLoading:s,onConfirm:n})}e.s(["DisconnectCloudDialog",()=>f],471402);var h=e.i(48105),g=e.i(732486),x=e.i(894437),y=e.i(666187),b=e.i(843542),j=e.i(46271),v=e.i(613109),E=e.i(79196);let N=({open:e,onOpenChange:a,handleConfirmIncrease:n,currentSizeGB:s,newSizeGB:i})=>(0,t.jsx)(E.Dialog,{open:e,onOpenChange:a,children:(0,t.jsxs)(E.DialogContent,{children:[(0,t.jsxs)(E.DialogHeader,{children:[(0,t.jsx)(E.DialogTitle,{children:"Confirm disk size increase"}),(0,t.jsxs)(E.DialogDescription,{children:["Increase disk size from ",s," GB to ",i," GB (+",i-s," GB)"]})]}),(0,t.jsxs)("div",{className:"flex flex-col gap-2 text-sm text-muted-foreground",children:[(0,t.jsx)("p",{className:"font-medium text-foreground",children:"Important limitations:"}),(0,t.jsxs)("ul",{className:"flex list-inside list-disc flex-col gap-1",children:[(0,t.jsx)("li",{children:"Disk can only be resized once every 4 hours"}),(0,t.jsx)("li",{children:"You can only increase size, not decrease"}),(0,t.jsx)("li",{children:"Increasing disk space will affect your cloud balance and usage charges"}),(0,t.jsx)("li",{children:"Resize operations may take several minutes"})]})]}),(0,t.jsxs)(E.DialogFooter,{children:[(0,t.jsx)(E.DialogClose,{asChild:!0,children:(0,t.jsx)(x.Button,{intent:"secondary",children:"No"})}),(0,t.jsx)(x.Button,{onClick:n,intent:"affirmative",children:"Yes, increase"})]})]})});function _(){let e=(0,i.useUpdateDiskConfig)(),{data:a}=(0,i.useGetDiskSpace)(),[n,s]=(0,h.useState)(""),[r,l]=(0,h.useState)(null),[o,c]=(0,h.useState)(!1),d=(0,h.useMemo)(()=>a?Math.ceil(a.size_bytes/0x40000000):0,[a]),u=(0,h.useMemo)(()=>a?a.used_bytes/0x40000000:0,[a]),p=(0,h.useMemo)(()=>a&&0!==a.size_bytes?a.used_bytes/a.size_bytes*100:0,[a]),m=(0,h.useMemo)(()=>a?Math.ceil(1.2*d):0,[a,d]),f=p>=85,E=null!==r&&r!==d;(0,h.useEffect)(()=>{null!==r&&d>=r&&l(null)},[d,r]);let _=""!==n,S=n?parseInt(n,10):0,w=!isNaN(S)&&S>0,C=w&&S<d,A=w&&S<8,T=!w||A||C,D=async()=>{try{l(S),await e.mutateAsync({attributes:{size_gb:S}}),s(""),c(!1),setTimeout(()=>l(null),12e4)}catch(e){l(null),c(!1)}};return(0,t.jsxs)("div",{className:"flex flex-col gap-4 rounded-lg border border-border bg-background p-4",children:[(0,t.jsxs)("div",{className:"flex flex-col gap-2",children:[(0,t.jsxs)("div",{className:"flex items-center justify-between",children:[(0,t.jsxs)("div",{className:"flex flex-col gap-0.5",children:[(0,t.jsx)("p",{className:"font-medium",children:"Disk space usage"}),a&&(0,t.jsxs)("p",{className:"text-xs text-muted-foreground",children:["Last updated: ",new Date(a.timestamp).toLocaleString()]})]}),(0,t.jsxs)("p",{className:"text-sm text-muted-foreground",children:[u.toFixed(2)," GB / ",d," GB"]})]}),a&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:"h-2 w-full overflow-hidden rounded-full bg-muted",children:(0,t.jsx)("div",{className:"h-full bg-primary transition-all",style:{width:`${p}%`}})}),(0,t.jsxs)("p",{className:"text-xs text-muted-foreground",children:[((a.size_bytes-a.used_bytes)/0x40000000).toFixed(2)," GB available"]})]})]}),E&&(0,t.jsxs)(g.Alert,{variant:"bordered",children:[(0,t.jsx)(y.InfoCircleIcon,{className:"h-4 w-4"}),(0,t.jsxs)(g.AlertDescription,{children:["Disk space is being updated to ",r," GB. This may take a few minutes to reflect in the usage metrics above."]})]}),f&&!E&&(0,t.jsxs)(g.Alert,{variant:"warning",children:[(0,t.jsx)(b.WarningCircleIcon,{className:"h-4 w-4"}),(0,t.jsxs)(g.AlertDescription,{children:["Your disk is nearly full (",p.toFixed(1),"% used). Consider increasing to at least"," ",m," GB to ensure smooth operation.",(0,t.jsx)(x.Button,{variant:"link",size:"sm",className:"ml-1 h-auto p-0 text-xs underline",onClick:()=>{s(m.toString())},children:"Use recommended size"})]})]}),(0,t.jsxs)(g.Alert,{variant:"bordered",children:[(0,t.jsx)(y.InfoCircleIcon,{className:"h-4 w-4"}),(0,t.jsxs)(g.AlertDescription,{className:"text-xs",children:[(0,t.jsx)("strong",{children:"Important limitations:"}),(0,t.jsxs)("ul",{className:"mt-1 list-inside list-disc space-y-0.5",children:[(0,t.jsx)("li",{children:"Disk can only be resized once every 4 hours"}),(0,t.jsx)("li",{children:"You can only increase size, not decrease"}),(0,t.jsx)("li",{children:"Increasing disk space will affect your cloud balance and usage charges"}),(0,t.jsx)("li",{children:"Resize operations may take several minutes"})]})]})]}),(0,t.jsxs)("div",{className:"flex flex-col gap-2",children:[(0,t.jsx)(v.Label,{htmlFor:"sizeGB",children:"New disk size (GB)"}),(0,t.jsx)(j.Input,{id:"sizeGB",type:"number",placeholder:`Minimum: ${Math.max(8,d+1)} GB`,value:n,onChange:e=>s(e.target.value),disabled:e.isPending,min:Math.max(8,d+1)}),_&&!w&&(0,t.jsx)("p",{className:"text-xs text-destructive",children:"Please enter a valid positive number."}),_&&w&&A&&(0,t.jsx)("p",{className:"text-xs text-destructive",children:"Minimum disk size is 8 GB. Please enter a larger value."}),_&&C&&(0,t.jsxs)("p",{className:"text-xs text-destructive",children:["Cannot decrease disk size. Current size is ",d," GB. Please enter a larger value."]}),_&&w&&S>d&&!A&&(0,t.jsxs)("p",{className:"text-xs text-muted-foreground",children:["Will increase disk size from ",d," GB to ",S," GB (+",S-d," GB)"]})]}),(0,t.jsxs)("div",{className:"flex justify-end gap-2",children:[_&&(0,t.jsx)(x.Button,{variant:"ghost",onClick:()=>{s("")},disabled:e.isPending,children:"Cancel"}),(0,t.jsx)(x.Button,{onClick:()=>{T||c(!0)},disabled:!_||e.isPending||T,variant:"solid",intent:"affirmative",children:e.isPending?"Updating...":"Increase disk size"})]}),(0,t.jsx)(N,{open:o,onOpenChange:c,handleConfirmIncrease:D,currentSizeGB:d,newSizeGB:S})]})}e.s(["UpdateDiskConfig",()=>_],753885)},538393,e=>{"use strict";var t=e.i(855205),a=e.i(48105),n=e.i(637967),s=e.i(770830),i=e.i(535786),r=e.i(109976),l=e.i(294268),o=e.i(606755),c=e.i(642655),d=e.i(853866),u=e.i(736262),p=e.i(894437),m=e.i(897163),f=e.i(666187),h=e.i(180580),g=e.i(689848),x=e.i(90434),y=e.i(258752),b=e.i(685960),j=e.i(669285),v=e.i(314658),E=e.i(838248),N=e.i(682213),_=e.i(92566),S=e.i(649350),w=e.i(883519),C=e.i(471402),A=e.i(753885),T=e.i(732486),D=e.i(72793),I=e.i(92154),R=e.i(622485),k=e.i(266038),O=e.i(780094),P=e.i(448020),L=e.i(844490);let U=()=>{let{shouldUpgradeCloudInstance:e,exhaustionRecords:a}=(0,L.useCloudInstanceExhaustion)();return e?(0,t.jsxs)(T.Alert,{variant:"warning",children:[(0,t.jsx)(D.CloudIcon,{size:"small"}),(0,t.jsx)(T.AlertTitle,{children:"Instance upgrade recommended"}),(0,t.jsxs)(T.AlertDescription,{children:[(0,t.jsx)("p",{children:"Your Cloud instance is almost out of resources. Upgrade now to keep performance fast and reliable."}),a.length>0&&(0,t.jsx)("div",{className:(0,P.cn)("mt-1 grid w-full grid-cols-1 gap-3",(1===a.length||2===a.length)&&"md:grid-cols-2",3===a.length&&"md:grid-cols-3"),children:a.map(e=>(0,t.jsx)(F,{record:e},e.resource_type))})]})]}):null},z={DiskSpace:{Icon:k.StorageIcon,label:"Disk space",valueFormatter:e=>`Using ${e}% of disk space.`,calculateDisplayValue:e=>100-e,explainer:"Disk space determines how much data your app can store. For example, if your app saves lots of images, you'll need more disk space."},DiskIO:{Icon:k.StorageIcon,label:"Disk read and write",valueFormatter:e=>`Using ${e}% of disk IO budget.`,calculateDisplayValue:e=>100-e,explainer:"Determines how much data your app can process. If your app updates storage data frequently, you'll need more disk read and write capacity."},CPU:{Icon:I.GaugeIcon,label:"CPU",valueFormatter:e=>`Using ${e}% of CPU capacity.`,calculateDisplayValue:e=>e,explainer:"Determines how much processing power your app has. If your app has lots of active users, you'll need more CPU power."}},F=({record:e})=>{let a=(e=>{if(z[e])return z[e]})(e.resource_type);if(!a)return null;let n=Math.round(Math.min(Math.max(0,Math.round(100*a.calculateDisplayValue(e.alert_value))/100),100)),{Icon:s}=a;return(0,t.jsxs)("div",{className:"flex w-full flex-col gap-2 rounded-lg bg-muted p-3",children:[(0,t.jsxs)("div",{className:"flex justify-between gap-2",children:[(0,t.jsxs)("div",{className:"flex flex-row items-center gap-2 md:flex-col md:items-start md:gap-1",children:[(0,t.jsx)(s,{size:"default"}),(0,t.jsx)("span",{className:"font-medium",children:a.label})]}),(0,t.jsx)(O.default,{icon:R.QuestionCircleIcon,className:"hidden md:flex",tooltipContentClassName:"max-w-[30ch]",children:(0,t.jsx)("p",{children:a.explainer})})]}),(0,t.jsx)("span",{className:"text-xs",children:a.valueFormatter(n)}),(0,t.jsx)("div",{className:"mt-auto h-3 w-full rounded-md bg-warning",children:(0,t.jsxs)(h.Tooltip,{children:[(0,t.jsx)(h.TooltipTrigger,{asChild:!0,children:(0,t.jsx)("div",{className:"h-full cursor-pointer rounded-md bg-warning-primary transition-opacity duration-150 ease-in-out hover:opacity-80",style:{width:`${n}%`}})}),(0,t.jsx)(h.TooltipContent,{children:(0,t.jsxs)("p",{children:[n,"% used"]})})]})})]})};var G=e.i(721636),M=e.i(79196);let B=({open:e,onOpenChange:a,handleConfirmResize:n,getInstanceChangeDescription:s,isSelectedInstanceUpgrade:i})=>{let r=s();return(0,t.jsx)(M.Dialog,{open:e,onOpenChange:a,children:(0,t.jsxs)(M.DialogContent,{children:[(0,t.jsxs)(M.DialogHeader,{children:[(0,t.jsx)(M.DialogTitle,{children:"Confirm instance resize"}),(0,t.jsxs)(M.DialogDescription,{children:[i?"Upgrade":"Downgrade"," instance from"," ",(0,t.jsx)(G.Badge,{variant:"affirmative",children:r.current})," to"," ",(0,t.jsx)(G.Badge,{variant:i?"success":"secondary",children:r.target})]})]}),(0,t.jsxs)("div",{className:"flex flex-col gap-2 text-sm text-muted-foreground",children:[(0,t.jsx)("p",{className:"font-medium text-foreground",children:"What to expect:"}),(0,t.jsxs)("ul",{className:"flex list-inside list-disc flex-col gap-1",children:[(0,t.jsx)("li",{children:"Resizing usually takes just a couple of minutes."}),(0,t.jsx)("li",{children:"There may be a brief interruption to your app while the resize finishes."}),(0,t.jsx)("li",{children:"You can’t make more changes until the resize is done."}),(0,t.jsx)("li",{children:i?"Larger sizes give you more capacity and may increase your costs":"Smaller sizes give you less capacity and may decrease performance"})]})]}),(0,t.jsxs)(M.DialogFooter,{children:[(0,t.jsx)(M.DialogClose,{asChild:!0,children:(0,t.jsx)(p.Button,{intent:"secondary",children:"Cancel"})}),(0,t.jsx)(p.Button,{onClick:n,intent:i?"affirmative":"default",children:i?"Upgrade instance":"Downgrade instance"})]})]})})};var $=e.i(564263),H=e.i(287432);let q=[{value:"xs",label:"Tiny",description:"Great for trying things out."},{value:"s",label:"Mini",description:"Reliable for early projects."},{value:"m",label:"Small",description:"Room to grow with your app."},{value:"l",label:"Medium",description:"Steady choice for regular use."},{value:"xl",label:"Large",description:"Confident for higher demand."}],W=[...q,{value:"xxl",label:"X-Large",description:"High-performance tier."}],K=({isDisabled:e,triggerLabel:a,triggerDescription:n,selectedInstanceType:s,setSelectedInstanceType:i,currentIndex:r,triggerBadgeVariant:l})=>{let o="xxl"===W[r]?.value?W:q;return(0,t.jsxs)($.DropdownMenu,{children:[(0,t.jsx)($.DropdownMenuTrigger,{asChild:!0,children:(0,t.jsxs)(p.Button,{variant:"outline",className:"flex w-full items-center justify-between rounded-lg px-3",disabled:e,size:"lg",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2",children:[a?(0,t.jsx)(G.Badge,{variant:l,children:a}):(0,t.jsx)("span",{children:"Select an instance size"}),(0,t.jsx)("span",{className:"text-wrap text-left text-sm font-normal",children:n})]}),(0,t.jsx)(H.ChevronDownIcon,{size:"small",className:"text-muted-foreground"})]})}),(0,t.jsx)($.DropdownMenuContent,{className:"max-h-[320px] w-[--radix-dropdown-menu-trigger-width] p-1",children:(0,t.jsx)($.DropdownMenuRadioGroup,{value:s,onValueChange:e=>{i(e)},children:o.map(e=>{let a=W.findIndex(t=>t.value===e.value),n=a===r;return(0,t.jsxs)($.DropdownMenuRadioItem,{value:e.value,disabled:n,arrowLocation:"end",className:"min-h-10",children:[(0,t.jsxs)("div",{className:"flex flex-wrap items-center gap-2",children:[(0,t.jsx)(G.Badge,{variant:a<r?"secondary":a>r?"success":"accent",className:"",children:e.label}),(0,t.jsx)("span",{className:"text-sm",children:e.description})]}),n&&(0,t.jsx)(G.Badge,{variant:"secondary",className:"ml-auto",children:"Current"})]},e.value)})})})]})};var Y=e.i(276402),Q=e.i(125779);let J=({isSelectedInstanceUpgrade:e})=>(0,t.jsx)("div",{className:"rounded-lg border p-5",children:(0,t.jsx)("div",{className:"flex flex-col gap-3",children:(0,t.jsxs)("div",{className:"grid gap-x-8 gap-y-4 text-sm text-muted-foreground lg:grid-cols-2",children:[(0,t.jsxs)("div",{className:"flex items-start gap-2",children:[(0,t.jsx)(Q.FileTextIcon,{size:"small",className:"mt-0.5 text-muted-foreground"}),(0,t.jsx)("span",{children:e?"Handles more traffic and users. Monthly costs increases accordingly.":"Handles less traffic and users. Monthly costs decrease accordingly."})]}),(0,t.jsxs)("div",{className:"flex items-start gap-2",children:[(0,t.jsx)(Y.ClockIcon,{size:"small",className:"mt-0.5 text-muted-foreground"}),(0,t.jsx)("span",{children:"Takes a few minutes. Users may experience a brief interruption."})]})]})})});function V(e){let{data:T,isLoading:D,refetch:I}=(0,j.useGetComputeSize)(),R=(0,j.useUpdateComputeSize)(),{data:k,isLoading:O}=(0,j.useGetStatus)({}),P=(0,l.useCurrentWorkspaceStore)(e=>e.currentWorkspace),L=(0,o.useProjectStore)(e=>e.project),z=(0,y.getPlanCategory)(P?.plan),F=(0,y.isCategoryGreaterOrEqual)(z,"ktlo"),G=(0,x.useIsDisconnectCloudEnabled)(),M=(0,j.useDisconnectCloud)(),{disableDevEnvironment:$,isDisabling:H}=(0,v.useDisableDevEnvironment)(),q=(0,i.useHasActiveLock)(),{openCarousel:Y}=(0,b.useDevProdCarousel)(),{supabaseIntegrationData:Q}=(0,E.useSupabaseIntegrationData)(L?.id),{setOpenShareMenu:V}=(0,r.useShareMenuContext)(),[Z,X]=(0,a.useState)(""),[ee,et]=(0,a.useState)(""),[ea,en]=(0,a.useState)(!1),[es,ei]=(0,a.useState)(!1),[er,el]=(0,a.useState)(!1),[eo,ec]=(0,a.useState)(),ed=!!Q?.dev;(0,a.useEffect)(()=>{T?.instance_type&&et(T.instance_type)},[T?.instance_type]),(0,a.useEffect)(()=>{"RESIZING"===eo&&k?.status==="OK"&&I(),ec(k?.status)},[k?.status,eo,I]);let eu=!!Z&&Z!==ee,ep=D||O,em=k?.status,ef="RESIZING"===em,eh=["RESIZING","UPGRADING","RESTARTING","COMING_UP","RESTORING"].includes(em||""),eg=!ep&&em&&"OK"!==em&&!eh,ex=ep||eh||eg||R.isPending||!F,ey=!ep&&em&&"OK"!==em?(e=>{switch(e){case"RESIZING":return{title:"Resize in progress",description:"Instance is being resized. This typically takes less than 2 minutes.",type:"info"};case"UPGRADING":return{title:"System upgrade in progress",description:"The database is being upgraded. Please wait for the process to complete.",type:"info"};case"RESTARTING":return{title:"Instance is restarting",description:"The database is restarting. It will be available shortly.",type:"info"};case"COMING_UP":return{title:"Instance is starting up",description:"The database is starting up and will be available soon.",type:"info"};case"RESTORING":return{title:"Restore in progress",description:"The database is being restored from a backup.",type:"info"};case"UNHEALTHY":return{title:"Instance is unhealthy",description:"The database is experiencing issues. Please contact support if this persists.",type:"error"};case"INACTIVE":return{title:"Instance is inactive",description:"The database is currently inactive.",type:"warning"};case"PAUSING":return{title:"Instance is pausing",description:"The database is being paused to save resources.",type:"info"};default:return{title:"Instance status unknown",description:"Unable to determine the current status of the database.",type:"warning"}}})(em):null,eb=!eu||eh||R.isPending||!F,ej=R.isPending?"Submitting your resize request...":ef?"A previous resize operation is still being processed. Please wait a few minutes.":eh?"Infrastructure changes are still in progress. Try again once the instance is ready.":F?void 0:"You need to upgrade your plan to change the instance size.",ev=W.find(e=>e.value===ee),eE=W.findIndex(e=>e.value===ee),eN=W.findIndex(e=>e.value===Z),e_=W.find(e=>e.value===Z),eS=Z?e_?.label:void 0,ew=Z?e_?.description:void 0,eC=Z?eN>eE?"success":eN<eE?"outline":"accent":"outline",eA=!!e_&&Z!==ee&&F,eT=async()=>{en(!1),await R.mutateAsync(Z)},eD=(0,d.useFeatureGateDialog)(),{exitView:eI}=(0,n.useViewContext)(),eR=eN>eE,ek=async()=>{await M.mutateAsync(),ei(!1),eI()},eO=async()=>{await $(),el(!1)};return(0,t.jsxs)(s.BackendContent,{canScroll:!0,className:"max-w-none",children:[(0,t.jsx)(_.SectionHeading,{title:"Advanced settings",description:"A bigger instance keeps your project running fast, stable, and ready for more users."}),(0,t.jsx)(U,{}),(0,t.jsx)(N.GeneralInfoCard,{}),(0,t.jsxs)("div",{className:"flex flex-col gap-6",children:[(0,t.jsxs)("div",{className:"flex flex-col gap-6 @lg/backend-content:flex-row",children:[(0,t.jsxs)("div",{className:"flex flex-1 flex-col gap-2",children:[(0,t.jsx)("div",{className:"flex h-7 items-center",children:(0,t.jsx)("p",{className:"font-medium",children:"Current size"})}),(0,t.jsx)(S.CurrentInstance,{statusInfo:ey,isLoading:ep,isTransitioning:eh,currentInstanceDetail:ev})]}),(0,t.jsxs)("div",{className:"flex flex-1 flex-col gap-2",children:[(0,t.jsxs)("div",{className:"flex items-center justify-between gap-2",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2",children:[(0,t.jsx)("p",{className:"font-medium",children:"Upgrade instance"}),P&&!F&&(0,t.jsx)(g.UpgradeBadge,{workspace:P,requiredPlanCategory:"pro"})]}),(0,t.jsx)(p.Button,{variant:"ghost",intent:"muted",className:"w-fit",size:"sm",asChild:!0,children:(0,t.jsxs)("a",{href:"https://docs.lovable.dev/features/cloud#advanced-settings-upgrade-instance",target:"_blank",onClick:e=>{F||e.stopPropagation()},children:[(0,t.jsx)(f.InfoCircleIcon,{size:"small"}),"Read more"]})})]}),(0,t.jsx)("div",{onClick:()=>{F||eD(u.FeatureGateScenario.PRO_CHANGE_CLOUD_INSTANCE_SIZE)},children:(0,t.jsx)(K,{isDisabled:ex,triggerLabel:eS,triggerDescription:ew,selectedInstanceType:Z,setSelectedInstanceType:X,currentIndex:eE,triggerBadgeVariant:eC})})]})]}),eA&&(0,t.jsx)(J,{isSelectedInstanceUpgrade:eR}),(0,t.jsx)("div",{className:"flex justify-end gap-2",children:(0,t.jsxs)("div",{className:"flex gap-2",children:[eu&&(0,t.jsx)(p.Button,{variant:"ghost",onClick:()=>X(""),children:"Cancel"}),(0,t.jsxs)(h.Tooltip,{open:!!ej&&void 0,children:[(0,t.jsx)(h.TooltipTrigger,{asChild:!0,children:(0,t.jsx)("span",{className:"inline-flex",children:(0,t.jsx)(p.Button,{onClick:()=>{Z&&eu&&en(!0)},disabled:eb,variant:eR?"solid":"outline",intent:eR?"affirmative":"muted",children:R.isPending?"Saving...":!Z||eR?"Upgrade instance":"Downgrade instance"})})}),ej&&(0,t.jsx)(h.TooltipContent,{side:"top",className:"max-w-xs text-center",children:ej})]})]})})]}),(0,t.jsx)(A.UpdateDiskConfig,{}),!ed&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("hr",{className:"my-4 border-border"}),(0,t.jsxs)("div",{className:"flex flex-col gap-4",children:[(0,t.jsxs)("p",{className:"flex items-center gap-2 text-lg font-medium",children:["Test and Live environments ",(0,t.jsx)(c.BetaBadge,{})]}),(0,t.jsxs)("div",{className:"flex items-center justify-between gap-4",children:[(0,t.jsxs)("div",{className:"flex flex-col gap-1",children:[(0,t.jsx)("p",{className:"font-medium",children:"Enable Live & Test environments"}),(0,t.jsx)("p",{className:"text-sm text-muted-foreground",children:L?.url?"Creates separate Test and Live environments. Your Test and Live data will be separate.":(0,t.jsxs)(t.Fragment,{children:["To enable Live & Test environments you need to"," ",(0,t.jsx)("button",{onClick:()=>{eI(),V("SHARE")},className:"underline hover:opacity-80",children:"publish your project"})]})})]}),(0,t.jsx)(m.ConditionalTooltip,{showTooltip:q,tooltipContent:"Wait for Lovable to finish working",children:(0,t.jsx)(p.Button,{variant:"outline",onClick:()=>{Y(!1)},disabled:!L?.url||q,children:"Enable"})})]})]})]}),(G||ed)&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("hr",{className:"my-4 border-border"}),(0,t.jsxs)("div",{className:"flex flex-col gap-4",children:[(0,t.jsx)("p",{className:"text-lg font-medium",children:"Danger zone"}),ed&&(0,t.jsxs)("div",{className:"flex items-center justify-between gap-4",children:[(0,t.jsxs)("div",{className:"flex flex-col gap-1",children:[(0,t.jsx)("p",{className:"font-medium",children:"Delete test database"}),(0,t.jsx)("p",{className:"text-sm text-muted-foreground",children:"Permanently deletes all test data. You can re-enable the test database later, but your data will not be restored."})]}),(0,t.jsx)(m.ConditionalTooltip,{showTooltip:q&&!H,tooltipContent:"Wait for Lovable to finish working",children:(0,t.jsx)(p.Button,{intent:"destructive",onClick:()=>el(!0),disabled:H||q,children:H?"Deleting...":"Delete"})})]}),G&&(0,t.jsxs)("div",{className:"flex items-center justify-between gap-4",children:[(0,t.jsxs)("div",{className:"flex flex-col gap-1",children:[(0,t.jsx)("p",{className:"text-sm font-medium",children:"Disconnect Cloud"}),(0,t.jsx)("p",{className:"text-sm text-muted-foreground",children:"This permanently deletes your database, storage, and functions. This action is irreversible and may cause parts of your app to stop working."})]}),(0,t.jsx)(p.Button,{intent:"destructive",onClick:()=>ei(!0),children:"Disconnect"})]})]})]}),(0,t.jsx)(B,{open:ea,onOpenChange:en,handleConfirmResize:eT,getInstanceChangeDescription:()=>{let e=W.find(e=>e.value===ee),t=W.find(e=>e.value===Z);return{current:e?.label||"Unknown",target:t?.label||"Unknown"}},isSelectedInstanceUpgrade:eR}),(0,t.jsx)(C.DisconnectCloudDialog,{open:es,onOpenChange:ei,onConfirm:ek,isLoading:M.isPending}),(0,t.jsx)(w.DisableDevEnvironmentDialog,{open:er,onOpenChange:el,onConfirm:eO,isLoading:H})]})}e.s(["AdvancedManager",()=>V],538393)},974982,167731,e=>{"use strict";var t=e.i(418883),a=e.i(69235),n=e.i(961078),s=e.i(488868);let i=/\{[^{}]+\}/g;function r(e,t,a){if(null==t)return"";if("object"==typeof t)throw Error("Deeply-nested arrays/objects aren’t supported. Provide your own `querySerializer()` to handle these.");return`${e}=${a?.allowReserved===!0?t:encodeURIComponent(t)}`}function l(e,t,a){if(!t||"object"!=typeof t)return"";let n=[],s={simple:",",label:".",matrix:";"}[a.style]||"&";if("deepObject"!==a.style&&!1===a.explode){for(let e in t)n.push(e,!0===a.allowReserved?t[e]:encodeURIComponent(t[e]));let s=n.join(",");switch(a.style){case"form":return`${e}=${s}`;case"label":return`.${s}`;case"matrix":return`;${e}=${s}`;default:return s}}for(let s in t){let i="deepObject"===a.style?`${e}[${s}]`:s;n.push(r(i,t[s],a))}let i=n.join(s);return"label"===a.style||"matrix"===a.style?`${s}${i}`:i}function o(e,t,a){if(!Array.isArray(t))return"";if(!1===a.explode){let n={form:",",spaceDelimited:"%20",pipeDelimited:"|"}[a.style]||",",s=(!0===a.allowReserved?t:t.map(e=>encodeURIComponent(e))).join(n);switch(a.style){case"simple":return s;case"label":return`.${s}`;case"matrix":return`;${e}=${s}`;default:return`${e}=${s}`}}let n={simple:",",label:".",matrix:";"}[a.style]||"&",s=[];for(let n of t)"simple"===a.style||"label"===a.style?s.push(!0===a.allowReserved?n:encodeURIComponent(n)):s.push(r(e,n,a));return"label"===a.style||"matrix"===a.style?`${n}${s.join(n)}`:s.join(n)}function c(e){return function(t){let a=[];if(t&&"object"==typeof t)for(let n in t){let s=t[n];if(null!=s){if(Array.isArray(s)){if(0===s.length)continue;a.push(o(n,s,{style:"form",explode:!0,...e?.array,allowReserved:e?.allowReserved||!1}));continue}if("object"==typeof s){a.push(l(n,s,{style:"deepObject",explode:!0,...e?.object,allowReserved:e?.allowReserved||!1}));continue}a.push(r(n,s,e))}}return a.join("&")}}function d(e,t){return e instanceof FormData?e:t&&"application/x-www-form-urlencoded"===(t.get instanceof Function?t.get("Content-Type")??t.get("content-type"):t["Content-Type"]??t["content-type"])?new URLSearchParams(e).toString():JSON.stringify(e)}function u(...e){let t=new Headers;for(let a of e)if(a&&"object"==typeof a)for(let[e,n]of a instanceof Headers?a.entries():Object.entries(a))if(null===n)t.delete(e);else if(Array.isArray(n))for(let a of n)t.append(e,a);else void 0!==n&&t.set(e,n);return t}function p(e){return e.endsWith("/")?e.substring(0,e.length-1):e}var m=e.i(48105),f=e.i(606755),h=e.i(475275),g=e.i(74185),x=e.i(348037),y=e.i(921776),b=e.i(207057),j=function(){function e(e,t){for(var a=0;a<t.length;a++){var n=t[a];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(t,a,n){return a&&e(t.prototype,a),n&&e(t,n),t}}(),v=Object.freeze(Object.defineProperties(["",""],{raw:{value:Object.freeze(["",""])}})),E=function(){function e(){for(var t=this,a=arguments.length,n=Array(a),s=0;s<a;s++)n[s]=arguments[s];if(!(this instanceof e))throw TypeError("Cannot call a class as a function");return this.tag=function(e){for(var a=arguments.length,n=Array(a>1?a-1:0),s=1;s<a;s++)n[s-1]=arguments[s];return"function"==typeof e?t.interimTag.bind(t,e):"string"==typeof e?t.transformEndResult(e):(e=e.map(t.transformString.bind(t)),t.transformEndResult(e.reduce(t.processSubstitutions.bind(t,n))))},n.length>0&&Array.isArray(n[0])&&(n=n[0]),this.transformers=n.map(function(e){return"function"==typeof e?e():e}),this.tag}return j(e,[{key:"interimTag",value:function(e,t){for(var a=arguments.length,n=Array(a>2?a-2:0),s=2;s<a;s++)n[s-2]=arguments[s];return this.tag(v,e.apply(void 0,[t].concat(n)))}},{key:"processSubstitutions",value:function(e,t,a){var n=this.transformSubstitution(e.shift(),t);return"".concat(t,n,a)}},{key:"transformString",value:function(e){return this.transformers.reduce(function(e,t){return t.onString?t.onString(e):e},e)}},{key:"transformSubstitution",value:function(e,t){return this.transformers.reduce(function(e,a){return a.onSubstitution?a.onSubstitution(e,t):e},e)}},{key:"transformEndResult",value:function(e){return this.transformers.reduce(function(e,t){return t.onEndResult?t.onEndResult(e):e},e)}}]),e}();let N=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"";return{onEndResult:function(t){if(""===e)return t.trim();if("start"===(e=e.toLowerCase())||"left"===e)return t.replace(/^\s*/,"");if("end"===e||"right"===e)return t.replace(/\s*$/,"");throw Error("Side not supported: "+e)}}},_=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"initial";return{onEndResult:function(t){if("initial"===e){var a=t.match(/^[^\S\n]*(?=\S)/gm),n=a&&Math.min.apply(Math,function(e){if(!Array.isArray(e))return Array.from(e);for(var t=0,a=Array(e.length);t<e.length;t++)a[t]=e[t];return a}(a.map(function(e){return e.length})));if(n){var s=RegExp("^.{"+n+"}","gm");return t.replace(s,"")}return t}if("all"===e)return t.replace(/^[^\S\n]+/gm,"");throw Error("Unknown type: "+e)}}},S=function(e,t){return{onEndResult:function(a){if(null==e||null==t)throw Error("replaceResultTransformer requires at least 2 arguments.");return a.replace(e,t)}}},w=function(e,t){return{onSubstitution:function(a,n){if(null==e||null==t)throw Error("replaceSubstitutionTransformer requires at least 2 arguments.");return null==a?a:a.toString().replace(e,t)}}};var C={separator:"",conjunction:"",serial:!1};let A=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:C;return{onSubstitution:function(t,a){if(Array.isArray(t)){var n=t.length,s=e.separator,i=e.conjunction,r=e.serial,l=a.match(/(\n?[^\S\n]+)$/);if(t=l?t.join(s+l[1]):t.join(s+" "),i&&n>1){var o=t.lastIndexOf(s);t=t.slice(0,o)+(r?s:"")+" "+i+t.slice(o+1)}}return t}}},T=function(e){return{onSubstitution:function(t,a){if(null!=e&&"string"==typeof e)"string"==typeof t&&t.includes(e)&&(t=t.split(e));else throw Error("You need to specify a string character to split by.");return t}}};var D=function(e){return null!=e&&!Number.isNaN(e)&&"boolean"!=typeof e};new E(A({separator:","}),_,N),new E(A({separator:",",conjunction:"and"}),_,N),new E(A({separator:",",conjunction:"or"}),_,N),new E(T("\n"),function(){return{onSubstitution:function(e){return Array.isArray(e)?e.filter(D):D(e)?e:""}}},A,_,N),new E(T("\n"),A,_,N,w(/&/g,"&amp;"),w(/</g,"&lt;"),w(/>/g,"&gt;"),w(/"/g,"&quot;"),w(/'/g,"&#x27;"),w(/`/g,"&#x60;")),new E(S(/(?:\n(?:\s*))+/g," "),N),new E(S(/(?:\n\s*)/g,""),N),new E(A({separator:","}),S(/(?:\s+)/g," "),N),new E(A({separator:",",conjunction:"or"}),S(/(?:\s+)/g," "),N),new E(A({separator:",",conjunction:"and"}),S(/(?:\s+)/g," "),N),new E(A,_,N),new E(A,S(/(?:\s+)/g," "),N);var I=new E(_,N);new E(_("all"),N);let R=`
-- Adapted from information_schema.columns

SELECT
  c.oid :: int8 AS table_id,
  nc.nspname AS schema,
  c.relname AS table,
  (c.oid || '.' || a.attnum) AS id,
  a.attnum AS ordinal_position,
  a.attname AS name,
  CASE
    WHEN a.atthasdef THEN regexp_replace(pg_get_expr(ad.adbin, ad.adrelid), '::[a-zA-Z0-9_ ]+$', '')
    ELSE NULL
  END AS default_value,
  CASE
    WHEN t.typtype = 'd' THEN CASE
      WHEN bt.typelem <> 0 :: oid
      AND bt.typlen = -1 THEN 'ARRAY'
      WHEN nbt.nspname = 'pg_catalog' THEN format_type(t.typbasetype, NULL)
      ELSE 'USER-DEFINED'
    END
    ELSE CASE
      WHEN t.typelem <> 0 :: oid
      AND t.typlen = -1 THEN 'ARRAY'
      WHEN nt.nspname = 'pg_catalog' THEN format_type(a.atttypid, NULL)
      ELSE 'USER-DEFINED'
    END
  END AS data_type,
  COALESCE(bt.typname, t.typname) AS format,
  a.attidentity IN ('a', 'd') AS is_identity,
  CASE
    a.attidentity
    WHEN 'a' THEN 'ALWAYS'
    WHEN 'd' THEN 'BY DEFAULT'
    ELSE NULL
  END AS identity_generation,
  a.attgenerated IN ('s') AS is_generated,
  NOT (
    a.attnotnull
    OR t.typtype = 'd' AND t.typnotnull
  ) AS is_nullable,
  (
    c.relkind IN ('r', 'p')
    OR c.relkind IN ('v', 'f') AND pg_column_is_updatable(c.oid, a.attnum, FALSE)
  ) AS is_updatable,
  uniques.table_id IS NOT NULL AS is_unique,
  check_constraints.definition AS "check",
  array_to_json(
    array(
      SELECT
        enumlabel
      FROM
        pg_catalog.pg_enum enums
      WHERE
        enums.enumtypid = coalesce(bt.oid, t.oid)
        OR enums.enumtypid = coalesce(bt.typelem, t.typelem)
      ORDER BY
        enums.enumsortorder
    )
  ) AS enums,
  col_description(c.oid, a.attnum) AS comment
FROM
  pg_attribute a
  LEFT JOIN pg_attrdef ad ON a.attrelid = ad.adrelid
  AND a.attnum = ad.adnum
  JOIN (
    pg_class c
    JOIN pg_namespace nc ON c.relnamespace = nc.oid
  ) ON a.attrelid = c.oid
  JOIN (
    pg_type t
    JOIN pg_namespace nt ON t.typnamespace = nt.oid
  ) ON a.atttypid = t.oid
  LEFT JOIN (
    pg_type bt
    JOIN pg_namespace nbt ON bt.typnamespace = nbt.oid
  ) ON t.typtype = 'd'
  AND t.typbasetype = bt.oid
  LEFT JOIN (
    SELECT DISTINCT ON (table_id, ordinal_position)
      conrelid AS table_id,
      conkey[1] AS ordinal_position
    FROM pg_catalog.pg_constraint
    WHERE contype = 'u' AND cardinality(conkey) = 1
  ) AS uniques ON uniques.table_id = c.oid AND uniques.ordinal_position = a.attnum
  LEFT JOIN (
    -- We only select the first column check
    SELECT DISTINCT ON (table_id, ordinal_position)
      conrelid AS table_id,
      conkey[1] AS ordinal_position,
      substring(
        pg_get_constraintdef(pg_constraint.oid, true),
        8,
        length(pg_get_constraintdef(pg_constraint.oid, true)) - 8
      ) AS "definition"
    FROM pg_constraint
    WHERE contype = 'c' AND cardinality(conkey) = 1
    ORDER BY table_id, ordinal_position, oid asc
  ) AS check_constraints ON check_constraints.table_id = c.oid AND check_constraints.ordinal_position = a.attnum
WHERE
  NOT pg_is_other_temp_schema(nc.oid)
  AND a.attnum > 0
  AND NOT a.attisdropped
  AND (c.relkind IN ('r', 'v', 'm', 'f', 'p'))
  AND (
    pg_has_role(c.relowner, 'USAGE')
    OR has_column_privilege(
      c.oid,
      a.attnum,
      'SELECT, INSERT, UPDATE, REFERENCES'
    )
  )
`,k=`
SELECT
    schemaname AS schema,
    relname AS name,
    n_live_tup AS live_rows_estimate
FROM
    pg_stat_user_tables
ORDER BY
    schemaname,
    relname
`,O=["information_schema","pg_catalog","pg_toast","_timescaledb_internal"];function P(e=[]){let t="",a=R+(t=e.length>0?`AND nc.nspname in (${e.map(e=>`'${e}'`).join(",")})`:`AND nc.nspname not in (${O.map(e=>`'${e}'`).join(",")})`),n=I`
    with
      tables as (${k}),
      columns as (${a}),
      table_columns as (
        select
          t.*,
          coalesce(
            json_agg(
              json_build_object(
                'name', c.name,
                'data_type', c.data_type,
                'is_nullable', c.is_nullable,
                'default_value', c.default_value,
                'ordinal_position', c.ordinal_position
              ) order by c.ordinal_position
            ) filter (where c.name is not null),
            '[]'::json
          ) as columns
        from tables t
        left join columns c on c.schema = t.schema and c.table = t.name
        group by t.schema, t.name, t.live_rows_estimate
      )
    select
      *
    from table_columns
  `;return n+="\n",e.length>0?n+=`where schema in (${e.map(e=>`quote_ident('${e}')`).join(",")})`:n+=`where schema not in (${O.map(e=>`'${e}'`).join(",")})`,n}function L(e,t=[]){let a=I`
    with
      tables as (${`
SELECT
  c.oid :: int8 AS id,
  nc.nspname AS schema,
  c.relname AS name,
  c.relrowsecurity AS rls_enabled,
  c.relforcerowsecurity AS rls_forced,
  CASE
    WHEN c.relreplident = 'd' THEN 'DEFAULT'
    WHEN c.relreplident = 'i' THEN 'INDEX'
    WHEN c.relreplident = 'f' THEN 'FULL'
    ELSE 'NOTHING'
  END AS replica_identity,
  pg_total_relation_size(format('%I.%I', nc.nspname, c.relname)) :: int8 AS bytes,
  pg_size_pretty(
    pg_total_relation_size(format('%I.%I', nc.nspname, c.relname))
  ) AS size,
  pg_stat_get_live_tuples(c.oid) AS live_rows_estimate,
  pg_stat_get_dead_tuples(c.oid) AS dead_rows_estimate,
  obj_description(c.oid) AS comment,
  coalesce(pk.primary_keys, '[]') as primary_keys,
  coalesce(
    jsonb_agg(relationships) filter (where relationships is not null),
    '[]'
  ) as relationships
FROM
  pg_namespace nc
  JOIN pg_class c ON nc.oid = c.relnamespace
  left join (
    select
      table_id,
      jsonb_agg(_pk.*) as primary_keys
    from (
      select
        n.nspname as schema,
        c.relname as table_name,
        a.attname as name,
        c.oid :: int8 as table_id
      from
        pg_index i,
        pg_class c,
        pg_attribute a,
        pg_namespace n
      where
        i.indrelid = c.oid
        and c.relnamespace = n.oid
        and a.attrelid = c.oid
        and a.attnum = any (i.indkey)
        and i.indisprimary
    ) as _pk
    group by table_id
  ) as pk
  on pk.table_id = c.oid
  left join (
    select
      c.oid :: int8 as id,
      c.conname as constraint_name,
      nsa.nspname as source_schema,
      csa.relname as source_table_name,
      sa.attname as source_column_name,
      nta.nspname as target_table_schema,
      cta.relname as target_table_name,
      ta.attname as target_column_name
    from
      pg_constraint c
    join (
      pg_attribute sa
      join pg_class csa on sa.attrelid = csa.oid
      join pg_namespace nsa on csa.relnamespace = nsa.oid
    ) on sa.attrelid = c.conrelid and sa.attnum = any (c.conkey)
    join (
      pg_attribute ta
      join pg_class cta on ta.attrelid = cta.oid
      join pg_namespace nta on cta.relnamespace = nta.oid
    ) on ta.attrelid = c.confrelid and ta.attnum = any (c.confkey)
    where
      c.contype = 'f'
  ) as relationships
  on (relationships.source_schema = nc.nspname and relationships.source_table_name = c.relname)
  or (relationships.target_table_schema = nc.nspname and relationships.target_table_name = c.relname)
WHERE
  c.relkind IN ('r', 'p')
  AND NOT pg_is_other_temp_schema(nc.oid)
  AND c.relname = quote_ident('${e}')
  AND (
    pg_has_role(c.relowner, 'USAGE')
    OR has_table_privilege(
      c.oid,
      'SELECT, INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'
    )
    OR has_any_column_privilege(c.oid, 'SELECT, INSERT, UPDATE, REFERENCES')
  )
group by
  c.oid,
  c.relname,
  c.relrowsecurity,
  c.relforcerowsecurity,
  c.relreplident,
  nc.nspname,
  pk.primary_keys
`}),
      columns as (${R})
    select
      *,
      ${U("columns","columns.table_id = tables.id")}
    from tables
  `;return a+="\n",t.length>0?a+=`where schema in (${t.map(e=>`quote_ident('${e}')`).join(",")})`:a+=`where schema not in (${O.map(e=>`'${e}'`).join(",")})`,a}let U=(e,t)=>I`
    COALESCE(
      (
        SELECT
          array_agg(row_to_json(${e})) FILTER (WHERE ${t})
        FROM
          ${e}
      ),
      '{}'
    ) AS ${e}
  `;e.s(["listTableInfoSql",()=>L,"listTablesNameRowCountSql",()=>P],167731);let z=I`
  SELECT
    schemaname,
    tablename,
    policyname,
    roles,
    cmd,
    qual,
    with_check
  FROM pg_policies
  WHERE schemaname = 'public'
  ORDER BY tablename, policyname;
`;I`
  SELECT
    c.oid :: int8 AS id,
    nc.nspname AS schema,
    c.relname AS name,
    c.relrowsecurity AS rls_enabled,
    pg_stat_get_live_tuples(c.oid) AS live_rows_estimate
  FROM
    pg_class c
    JOIN pg_namespace nc ON c.relnamespace = nc.oid
  WHERE
    nc.nspname = 'public'
    AND c.relkind IN ('r', 'p')
  ORDER BY c.relname;
`;let F=(0,h.getGoApiBaseUrl)(),G=()=>{let e=(0,f.useProjectStore)(e=>e.project?.id),{selectedInstance:t}=(0,f.useSelectedCloudInstance)();return(0,m.useMemo)(()=>e?function(e){let{baseUrl:t="",Request:a=globalThis.Request,fetch:n=globalThis.fetch,querySerializer:m,bodySerializer:f,headers:h,requestInitExt:g,...x}={...e};g="object"==typeof s.default&&Number.parseInt(s.default?.versions?.node?.substring(0,2))>=18&&s.default.versions.undici?g:void 0,t=p(t);let y=[];async function b(e,s){var b,j;let v,E,N,_,S,{baseUrl:w,fetch:C=n,Request:A=a,headers:T,params:D={},parseAs:I="json",querySerializer:R,bodySerializer:k=f??d,body:O,...P}=s||{},L=t;w&&(L=p(w)??t);let U="function"==typeof m?m:c(m);R&&(U="function"==typeof R?R:c({..."object"==typeof m?m:{},...R}));let z=void 0===O?void 0:k(O,u(h,T,D.header)),F=u(void 0===z||z instanceof FormData?{}:{"Content-Type":"application/json"},h,T,D.header),G={redirect:"follow",...x,...P,body:z,headers:F},M=new a((b=e,j={baseUrl:L,params:D,querySerializer:U},v=`${j.baseUrl}${b}`,j.params?.path&&(v=function(e,t){let a=e;for(let n of e.match(i)??[]){let e=n.substring(1,n.length-1),s=!1,i="simple";if(e.endsWith("*")&&(s=!0,e=e.substring(0,e.length-1)),e.startsWith(".")?(i="label",e=e.substring(1)):e.startsWith(";")&&(i="matrix",e=e.substring(1)),!t||void 0===t[e]||null===t[e])continue;let c=t[e];if(Array.isArray(c)){a=a.replace(n,o(e,c,{style:i,explode:s}));continue}if("object"==typeof c){a=a.replace(n,l(e,c,{style:i,explode:s}));continue}if("matrix"===i){a=a.replace(n,`;${r(e,c)}`);continue}a=a.replace(n,"label"===i?`.${encodeURIComponent(c)}`:encodeURIComponent(c))}return a}(v,j.params.path)),(E=j.querySerializer(j.params.query??{})).startsWith("?")&&(E=E.substring(1)),E&&(v+=`?${E}`),v),G);for(let e in P)e in M||(M[e]=P[e]);if(y.length){for(let t of(N=Math.random().toString(36).slice(2,11),_=Object.freeze({baseUrl:L,fetch:C,parseAs:I,querySerializer:U,bodySerializer:k}),y))if(t&&"object"==typeof t&&"function"==typeof t.onRequest){let n=await t.onRequest({request:M,schemaPath:e,params:D,options:_,id:N});if(n)if(n instanceof a)M=n;else if(n instanceof Response){S=n;break}else throw Error("onRequest: must return new Request() or Response() when modifying the request")}}if(!S){try{S=await C(M,g)}catch(a){let t=a;if(y.length)for(let a=y.length-1;a>=0;a--){let n=y[a];if(n&&"object"==typeof n&&"function"==typeof n.onError){let a=await n.onError({request:M,error:t,schemaPath:e,params:D,options:_,id:N});if(a){if(a instanceof Response){t=void 0,S=a;break}if(a instanceof Error){t=a;continue}throw Error("onError: must return new Response() or instance of Error")}}}if(t)throw t}if(y.length)for(let t=y.length-1;t>=0;t--){let a=y[t];if(a&&"object"==typeof a&&"function"==typeof a.onResponse){let t=await a.onResponse({request:M,response:S,schemaPath:e,params:D,options:_,id:N});if(t){if(!(t instanceof Response))throw Error("onResponse: must return new Response() when modifying the response");S=t}}}}if(204===S.status||"HEAD"===M.method||"0"===S.headers.get("Content-Length"))return S.ok?{data:void 0,response:S}:{error:void 0,response:S};if(S.ok)return"stream"===I?{data:S.body,response:S}:{data:await S[I](),response:S};let B=await S.text();try{B=JSON.parse(B)}catch{}return{error:B,response:S}}return{request:(e,t,a)=>b(t,{...a,method:e.toUpperCase()}),GET:(e,t)=>b(e,{...t,method:"GET"}),PUT:(e,t)=>b(e,{...t,method:"PUT"}),POST:(e,t)=>b(e,{...t,method:"POST"}),DELETE:(e,t)=>b(e,{...t,method:"DELETE"}),OPTIONS:(e,t)=>b(e,{...t,method:"OPTIONS"}),HEAD:(e,t)=>b(e,{...t,method:"HEAD"}),PATCH:(e,t)=>b(e,{...t,method:"PATCH"}),TRACE:(e,t)=>b(e,{...t,method:"TRACE"}),use(...e){for(let t of e)if(t){if("object"!=typeof t||!("onRequest"in t||"onResponse"in t||"onError"in t))throw Error("Middleware must be an object with one of `onRequest()`, `onResponse() or `onError()`");y.push(t)}},eject(...e){for(let t of e){let e=y.indexOf(t);-1!==e&&y.splice(e,1)}}}}({baseUrl:`${F}/projects/${e}/cloud/db-proxy`,fetch:async e=>{let a=await y.tokenManager.getValidToken();if(!a)throw Error("No token available");let n=new URL(e.url);n.searchParams.set("env",t);let s=new Headers(e.headers);for(let[e,t]of(s.set("Authorization",`Bearer ${a}`),Object.entries((0,g.getApiEnvironmentHeaders)())))s.set(e,t);let i=null;return"GET"!==e.method&&"HEAD"!==e.method&&(i=await e.clone().text()),fetch(n.toString(),{method:e.method,headers:s,body:i})}}):null,[e,t])},M=async({projectRef:e,query:t,readOnly:a,dbClient:n,signal:s})=>{let{data:i,error:r}=await n.POST("/v1/projects/{ref}/database/query",{params:{path:{ref:e}},body:{query:t,read_only:a},signal:s});if(r)throw r;return i},B=async(e,t,a)=>{let n=`SELECT COUNT(*) AS total FROM ${t}`,s=await M({projectRef:e,query:n,readOnly:!0,dbClient:a});return s?.[0]?.total??0},$=async(e,t)=>{let{data:a,error:n}=await t.GET("/v1/projects/{ref}/functions",{params:{path:{ref:e}}});if(n)throw n;return a??[]},H=async(e,t)=>M({projectRef:e,query:z,readOnly:!0,dbClient:t}),q=async({projectRef:e,dbClient:t})=>{let{data:a,error:n}=await t.POST("/v1/projects/{ref}/restore",{params:{path:{ref:e}}});if(n)throw n;return a};e.s(["useGetRLSPolicies",0,e=>{let t=G(),{selectedInstance:n}=(0,f.useSelectedCloudInstance)();return(0,a.useQuery)({queryKey:b.cloudKeys.database.rlsPolicies(e,n),queryFn:()=>H(e,t),enabled:!!e&&!!t,retry:!1})},"useGetTableCount",0,(e,t)=>{let n=G(),{selectedInstance:s}=(0,f.useSelectedCloudInstance)();return(0,a.useQuery)({queryKey:b.cloudKeys.database.tableCount(e,s,t),queryFn:()=>B(e,t,n),enabled:!!e&&!!t&&!!n,retry:!1})},"useGetUserCountsByDay",0,(e,t)=>{let n=G(),{selectedInstance:s}=(0,f.useSelectedCloudInstance)();return(0,a.useQuery)({queryKey:b.cloudKeys.database.userCounts(e,s,t),queryFn:()=>(({projectRef:e,days:t,dbClient:a})=>M({projectRef:e,query:`
    WITH days_series AS (
      SELECT generate_series(
        date_trunc('day', now() - interval '${Number(t)-1} days'),
        date_trunc('day', now()),
        '1 day'::interval
      )::date AS date
    )
    SELECT
      d.date,
      COALESCE(u.users, 0)::int as users
    FROM
      days_series d
    LEFT JOIN (
      SELECT
        date_trunc('day', created_at AT TIME ZONE 'UTC')::date as date,
        count(id) as users
      FROM
        auth.users
      GROUP BY 1
    ) u ON d.date = u.date
    ORDER BY
      d.date ASC;
  `,readOnly:!0,dbClient:a}))({projectRef:e,days:t,dbClient:n}),enabled:!!e&&!!n,retry:!1})},"useListFunctions",0,e=>{let t=G(),{selectedInstance:n}=(0,f.useSelectedCloudInstance)();return(0,a.useQuery)({queryKey:b.cloudKeys.database.functions(e,n),queryFn:()=>$(e,t),enabled:!!e&&!!t,retry:!1,refetchOnMount:"always"})},"useListTables",0,(e,t)=>{let n=G(),{selectedInstance:s}=(0,f.useSelectedCloudInstance)();return(0,a.useQuery)({queryKey:b.cloudKeys.database.tables(e,s,t),queryFn:()=>(({projectRef:e,schemas:t,dbClient:a})=>M({projectRef:e,query:P(t),readOnly:!0,dbClient:a}))({projectRef:e,schemas:t,dbClient:n}),enabled:!!e&&!!n})},"useRestoreProject",0,()=>{let e=(0,n.useQueryClient)(),a=G(),s=(0,f.useProjectStore)(e=>e.project?.id),{selectedInstance:i}=(0,f.useSelectedCloudInstance)();return(0,t.useMutation)({mutationFn:({projectRef:e})=>{if(!a)throw Error("Database client not available");return q({projectRef:e,dbClient:a})},onSuccess:()=>{e.invalidateQueries({queryKey:b.cloudKeys.status(s,i)})},onError:e=>{(0,x.showErrorToast)(e)},retry:3,retryDelay:e=>Math.min(2e3*2**e,1e4)})},"useRunQuery",0,()=>{let e=G();return(0,t.useMutation)({mutationFn:({projectRef:t,query:a,readOnly:n,signal:s})=>{if(!e)throw Error("Database client not available");return M({projectRef:t,query:a,readOnly:n,dbClient:e,signal:s})},onError:e=>{e instanceof DOMException&&"AbortError"===e.name||(0,x.showErrorToast)(e)}})}],974982)},84596,e=>{"use strict";var t=e.i(48105),a=e.i(616337),n=e.i(669285),s=e.i(974982),i=e.i(446129);e.s(["useLovableCloudPausedWithRestore",0,({project:e,projectRef:r})=>{let[l,o]=(0,a.default)(`hasTriggeredRestore-${e?.id}`,{defaultValue:{hasTriggered:!1,triggeredAt:0}}),c=(0,s.useRestoreProject)(),d=(0,t.useRef)([]),{hasTriggered:u,triggeredAt:p}=l,m=Date.now()-p,f=u&&m>6e5;(0,t.useEffect)(()=>{f&&o({hasTriggered:!1,triggeredAt:0})},[f,o]);let h=(0,i.useProjectHasLovableCloudEnabled)(e),{data:g,dataUpdatedAt:x,isLoading:y,error:b}=(0,n.useGetStatus)({refetchIntervalWhenTransitioning:1e3,refetchInterval:u?1e3:3e4}),j=g?.status;(0,t.useEffect)(()=>{"INACTIVE"!==j||c.isPending||u||!r||(o({hasTriggered:!0,triggeredAt:Date.now()}),c.mutate({projectRef:r}))},[j,r,c,u,o]),(0,t.useEffect)(()=>{"RESTORING"!==j||u||o({hasTriggered:!0,triggeredAt:Date.now()})},[j,u,o]),(0,t.useEffect)(()=>{j&&(d.current.push(j),d.current.length>10&&(d.current=d.current.slice(-10)))},[j,x]);let v=d.current.length>=10,E=d.current.every(e=>"OK"===e),N=v&&E;(0,t.useEffect)(()=>{N&&(o({hasTriggered:!1,triggeredAt:0}),d.current=[])},[N,o]);let _="PAUSING"===j,S=u&&!N,w=!_&&!S,C=(0,t.useCallback)(()=>{r&&w&&(o({hasTriggered:!0,triggeredAt:Date.now()}),c.mutate({projectRef:r}))},[r,w,o,c]);return{isRestoring:S,isPaused:"INACTIVE"===j||"PAUSING"===j,isHealthy:"OK"===j,isPausing:_,canTriggerRestore:w,hasError:b,isLovableCloudProject:h,isBackendStatusLoading:y,triggerRestore:C}}])},665136,e=>{"use strict";var t=e.i(69235),a=e.i(743339);e.s(["useAIGatewayData",0,({projectId:e,enabled:n=!0})=>(0,t.useQuery)({queryKey:["projects",e,"integrations","ai_gateway"],queryFn:async()=>(0,a.getGoApi)().get(`/projects/${e}/integrations/ai_gateway`),enabled:n&&!!e})])},541804,167425,e=>{"use strict";var t=e.i(251420),a=e.i(778743);function n(e,t){return+(0,a.startOfDay)(e)==+(0,a.startOfDay)(t)}function s(e){return n(e,(0,t.constructNow)(e))}e.s(["isToday",()=>s],541804);var i=e.i(100217);function r(e){return n(e,(0,i.subDays)((0,t.constructNow)(e),1))}e.s(["isYesterday",()=>r],167425)}]);

//# debugId=11f87d8f-7d0e-f19d-de24-8123cb7ef94e